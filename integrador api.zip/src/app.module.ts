import { Module } from '@nestjs/common';
import { UsuarioModule } from './usuario/usuario.module';
import { UsuarioController } from './usuario/usuario.controller';


@Module({
  imports: [UsuarioModule],
  controllers: [UsuarioController],
  providers: [],
})
export class AppModule {}
